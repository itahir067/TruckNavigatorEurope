# Truck Navigator Europe 0.4.0 — Android MVP

## Included
- Android Java app source and Android Studio project.
- OpenStreetMap raster map display through osmdroid, with visible attribution.
- Android GPS location and follow-my-location.
- One-shot destination search through Nominatim (no autocomplete).
- Truck route requests using Valhalla `costing: truck`; no silent car-route fallback.
- Editable vehicle height, width, combination length, gross weight, axle load, axle count and generic HAZMAT flag.
- Route geometry, summary, maneuver text, Android text-to-speech prompts and a basic off-route distance alert.
- Configurable router URL. Defaults to the public Valhalla demo for light testing.
- GitHub Actions workflow to build a debug APK.
- Optional self-hosted Valhalla backend instructions.

## Build the installable debug APK
1. Install Android Studio and Android SDK Platform 35.
2. Open this folder in Android Studio and allow Gradle sync.
3. Connect an Android phone with USB debugging enabled.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. APK: `app/build/outputs/apk/debug/app-debug.apk`.

Or push the project to a GitHub repository, then open **Actions → Build Truck Navigator Europe APK**. Download the `TruckNavigatorEurope-0.4.0-debug-apk` artifact.

## Routing
The app uses Valhalla truck costing with the fields documented by Valhalla: height, width, length, weight, axle_load, axle_count and hazmat. The default community demo server is fair-use/testing only; it can be rate limited or unavailable. For regular use, deploy your own backend using `backend/README.md`, then set its base URL in ROUTER settings.

## Free data / licences
- OpenStreetMap data is available under ODbL; attribution and applicable share-alike obligations apply.
- Standard OSM raster tiles at `tile.openstreetmap.org` are for normal interactive map viewing only. The OSM Foundation prohibits bulk tile scraping/prefetch and offline-area download features on that endpoint. This app does not offer offline tile downloads.
- Nominatim public geocoding is a community service with usage limits. The app makes one-shot searches only.
- Valhalla is open source. Self-hosting requires hardware, disk, updates and administration; free software does not make a 24/7 Europe-wide service free to operate.

## Safety / not yet production-ready
This is an engineering MVP, **not a certified professional truck navigation product** and has not been independently road-tested.
- OSM restriction coverage is incomplete and differs by country and road.
- Stock Valhalla's generic HAZMAT flag is not a complete ADR class / ADR tunnel-category engine.
- The foreground service keeps GPS route monitoring and basic manoeuvre prompts alive while the app is backgrounded, but it is not certified navigation and does not provide guaranteed map matching or automatic rerouting. Live traffic, offline maps, truck parking/fuel POIs, speed-camera alerts and a guaranteed data-update pipeline are not included.
- Maneuver prompts are basic and not a substitute for signs, driver judgement, official restrictions, company procedures or a certified navigation system.
- Never proceed when signage or local rules contradict the route. Do not use this MVP as your only navigation device.

## Stack
Android / Java · osmdroid · OpenStreetMap · Nominatim · Valhalla · Android GPS · Android TextToSpeech
