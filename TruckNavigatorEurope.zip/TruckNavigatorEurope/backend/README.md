# Optional self-hosted Valhalla truck router

The Android app uses Valhalla's `truck` costing model and accepts a base URL in ROUTER settings.
This deployment guide is a starting point, not a managed hosting service.

## Requirements
- Linux x86-64 server/workstation with Docker Engine + Compose plugin.
- RAM and disk depend heavily on extract size. Start with Italy or one country.
- OSM truck restriction tags may be incomplete.

## 1) Download one regional OSM extract
Examples:
- Italy: https://download.geofabrik.de/europe/italy-latest.osm.pbf
- Germany: https://download.geofabrik.de/europe/germany-latest.osm.pbf
- France: https://download.geofabrik.de/europe/france-latest.osm.pbf
- Europe: https://download.geofabrik.de/europe-latest.osm.pbf (very large; not suitable for a small PC)

Put the selected file at `data/region.osm.pbf`.

## 2) Build Valhalla tiles
```bash
mkdir -p data/tiles
docker run --rm -v "$PWD/data:/custom_files" ghcr.io/valhalla/valhalla:latest \
  valhalla_build_config --mjolnir-tile-dir /custom_files/tiles \
  --mjolnir-tile-extract /custom_files/tiles.tar > data/valhalla.json

docker run --rm -v "$PWD/data:/custom_files" ghcr.io/valhalla/valhalla:latest \
  valhalla_build_tiles -c /custom_files/valhalla.json /custom_files/region.osm.pbf

docker run --rm -v "$PWD/data:/custom_files" ghcr.io/valhalla/valhalla:latest \
  tar -cf /custom_files/tiles.tar -C /custom_files/tiles .
```
Check the CLI flags against the exact image release you use. Keep `valhalla.json`, `tiles/` and `tiles.tar` together.

## 3) Start service
```bash
docker compose up -d
```
The compose file binds port 8002 to localhost only. Put it behind an HTTPS reverse proxy and authentication before remote use. Configure the app ROUTER URL as your HTTPS base URL.

## 4) Truck profile support
The client sends `costing="truck"` with height, width, length, weight, axle_load, axle_count and generic boolean hazmat.

## Important
Stock Valhalla truck costing supports truck access and mapped dimensions/weight restrictions plus a generic hazmat flag. It is not a complete ADR class / ADR tunnel-code compliance engine. OSM restriction coverage varies. Missing tags do not mean a road is legal. Public demo routers are fair-use test services, not production infrastructure. Do not use this MVP as the only source of route legality.
