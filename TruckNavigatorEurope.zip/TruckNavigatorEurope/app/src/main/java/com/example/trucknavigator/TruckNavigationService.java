package com.example.trucknavigator;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.IBinder;
import android.speech.tts.TextToSpeech;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Locale;

/**
 * Foreground location monitor for an active route.
 * This keeps the route monitor alive while the app is backgrounded.
 * It is not a certified navigation or map-matching engine.
 */
public class TruckNavigationService extends Service implements LocationListener {
    public static final String ACTION_START = "com.example.trucknavigator.START_NAV";
    public static final String ACTION_STOP = "com.example.trucknavigator.STOP_NAV";
    public static final String EXTRA_POINTS = "route_points";
    public static final String EXTRA_MANEUVER_INDEXES = "maneuver_indexes";
    public static final String EXTRA_MANEUVER_TEXTS = "maneuver_texts";
    private static final String CHANNEL_ID = "truck_navigation";
    private static final int NOTIFICATION_ID = 4101;

    private final ArrayList<double[]> points = new ArrayList<>();
    private final ArrayList<Integer> maneuverIndexes = new ArrayList<>();
    private final ArrayList<String> maneuverTexts = new ArrayList<>();
    private LocationManager locationManager;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private int announced = -1;
    private int offRouteCount = 0;
    private NotificationManager notificationManager;

    @Override public void onCreate() {
        super.onCreate();
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        createChannel();
        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) {
                int r = tts.setLanguage(Locale.getDefault());
                ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED;
            }
        });
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_START.equals(intent.getAction())) {
            try {
                readRoute(intent);
                startForeground(NOTIFICATION_ID, buildNotification("Navigation monitoring active"));
                requestLocation();
            } catch (Exception e) {
                stopSelf();
            }
        }
        return START_STICKY;
    }

    private void readRoute(Intent intent) throws Exception {
        points.clear();
        maneuverIndexes.clear();
        maneuverTexts.clear();
        JSONArray p = new JSONArray(intent.getStringExtra(EXTRA_POINTS));
        for (int i = 0; i < p.length(); i++) {
            JSONArray xy = p.getJSONArray(i);
            points.add(new double[]{xy.getDouble(0), xy.getDouble(1)});
        }
        JSONArray mi = new JSONArray(intent.getStringExtra(EXTRA_MANEUVER_INDEXES));
        JSONArray mt = new JSONArray(intent.getStringExtra(EXTRA_MANEUVER_TEXTS));
        for (int i = 0; i < mi.length(); i++) maneuverIndexes.add(mi.getInt(i));
        for (int i = 0; i < mt.length(); i++) maneuverTexts.add(mt.getString(i));
    }

    private void requestLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            stopSelf();
            return;
        }
        try {
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2500L, 8f, this);
            } else {
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 5000L, 15f, this);
            }
        } catch (SecurityException ignored) {
            stopSelf();
        }
    }

    @Override public void onLocationChanged(Location location) {
        if (points.size() < 2) return;
        int nearest = 0;
        float min = Float.MAX_VALUE;
        float[] distance = new float[1];
        for (int i = 0; i < points.size(); i++) {
            double[] p = points.get(i);
            Location.distanceBetween(location.getLatitude(), location.getLongitude(),
                    p[0], p[1], distance);
            if (distance[0] < min) { min = distance[0]; nearest = i; }
        }

        if (min > 120f) offRouteCount++; else offRouteCount = 0;
        if (offRouteCount >= 3) {
            notificationManager.notify(NOTIFICATION_ID,
                    buildNotification("Off route / GPS drift: stop safely and check route"));
            return;
        }

        for (int i = 0; i < maneuverIndexes.size(); i++) {
            if (maneuverIndexes.get(i) >= nearest && i != announced) {
                announced = i;
                String text = maneuverTexts.get(i);
                notificationManager.notify(NOTIFICATION_ID, buildNotification(text));
                if (ttsReady) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "bg_maneuver_" + i);
                break;
            }
        }
    }

    private Notification buildNotification(String text) {
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_menu_directions)
                .setContentTitle("Truck Navigator Europe")
                .setContentText(text)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(text))
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(NotificationCompat.CATEGORY_NAVIGATION)
                .build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    "Truck navigation", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Active truck route monitoring and manoeuvre alerts");
            notificationManager.createNotificationChannel(channel);
        }
    }

    @Override public void onProviderEnabled(String provider) {}
    @Override public void onProviderDisabled(String provider) {}
    @Override public void onStatusChanged(String provider, int status, android.os.Bundle extras) {}

    @Override public void onDestroy() {
        try { locationManager.removeUpdates(this); } catch (Exception ignored) {}
        if (tts != null) { tts.stop(); tts.shutdown(); }
        stopForeground(true);
        super.onDestroy();
    }

    @Nullable @Override public IBinder onBind(Intent intent) { return null; }
}
