package com.example.trucknavigator;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.Intent;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import org.json.JSONArray;
import org.json.JSONObject;
import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Marker;
import org.osmdroid.views.overlay.Polyline;
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider;
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Truck Navigator Europe.
 *
 * This client deliberately asks Valhalla for costing="truck"; it never silently
 * substitutes a car route. Truck routing quality is limited by the OSM data
 * loaded into the configured Valhalla server and by the completeness of OSM tags.
 */
public class MainActivity extends AppCompatActivity {
    private static final int LOCATION_PERMISSION = 41;
    private static final String PREFS = "truck_profile";
    // Public community demo: fair-use/testing only, not a production service.
    private static final String DEMO_ROUTER = "https://valhalla1.openstreetmap.de";
    private static final String CLIENT_ID = "truck-navigator-europe-android";
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private MapView map;
    private MyLocationNewOverlay locationOverlay;
    private GeoPoint currentPoint, destinationPoint;
    private Marker destinationMarker;
    private Polyline routeLine;
    private TextView status, instruction, tripInfo;
    private EditText destinationInput;
    private TextToSpeech tts;
    private boolean ttsReady;
    private SharedPreferences prefs;

    private final ArrayList<GeoPoint> activeRoutePoints = new ArrayList<>();
    private final ArrayList<Integer> maneuverIndexes = new ArrayList<>();
    private final ArrayList<String> maneuverTexts = new ArrayList<>();
    private int lastAnnouncedManeuver = -1;
    private long lastRerouteAt = 0L;
    private boolean routeRequestRunning = false;

    private final Runnable progressTask = new Runnable() {
        @Override public void run() {
            updateNavigationProgress();
            mainHandler.postDelayed(this, 2500);
        }
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        Configuration.getInstance().setUserAgentValue("TruckNavigatorEurope/0.3.0 (Android)");
        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) {
                int languageResult = tts.setLanguage(Locale.getDefault());
                ttsReady = languageResult != TextToSpeech.LANG_MISSING_DATA
                        && languageResult != TextToSpeech.LANG_NOT_SUPPORTED;
            }
        });
        buildUi();
        if (hasLocationPermission()) enableLocation();
        else ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_PERMISSION);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF101820);

        TextView title = label("TRUCK NAVIGATOR EUROPE  •  0.3.0", 17, true);
        title.setPadding(14, 12, 10, 8);
        root.addView(title);

        LinearLayout search = new LinearLayout(this);
        search.setPadding(7, 2, 7, 2);
        destinationInput = new EditText(this);
        destinationInput.setSingleLine(true);
        destinationInput.setTextColor(Color.WHITE);
        destinationInput.setHintTextColor(0xFFBBBBBB);
        destinationInput.setHint("Destination / address");
        search.addView(destinationInput, new LinearLayout.LayoutParams(0, -2, 1));
        Button find = button("FIND");
        find.setOnClickListener(v -> searchDestination());
        search.addView(find);
        root.addView(search);

        map = new MapView(this);
        map.setTileSource(TileSourceFactory.MAPNIK);
        map.setMultiTouchControls(true);
        map.getController().setZoom(6.0);
        map.getController().setCenter(new GeoPoint(45.4408, 12.3155));
        root.addView(map, new LinearLayout.LayoutParams(-1, 0, 1));

        instruction = label("Enter a destination. Wait for GPS before requesting a route.", 15, true);
        instruction.setPadding(12, 7, 12, 2);
        root.addView(instruction);

        tripInfo = label("No active route", 12, false);
        tripInfo.setPadding(12, 2, 12, 2);
        root.addView(tripInfo);

        status = label("Truck routing: community demo server (fair use)", 11, false);
        status.setPadding(12, 2, 12, 6);
        root.addView(status);

        LinearLayout controls = new LinearLayout(this);
        controls.setGravity(Gravity.CENTER);
        controls.setBackgroundColor(0xFF182630);
        Button gps = button("GPS");
        gps.setOnClickListener(v -> enableLocation());
        controls.addView(gps);
        Button route = button("TRUCK ROUTE");
        route.setOnClickListener(v -> calculateTruckRoute(false));
        controls.addView(route);
        Button profile = button("VEHICLE");
        profile.setOnClickListener(v -> showProfile());
        controls.addView(profile);
        Button server = button("ROUTER");
        server.setOnClickListener(v -> configureServer());
        controls.addView(server);
        Button startNav = button("START NAV");
        startNav.setOnClickListener(v -> startBackgroundNavigation());
        controls.addView(startNav);
        Button stopNav = button("STOP");
        stopNav.setOnClickListener(v -> stopBackgroundNavigation());
        controls.addView(stopNav);
        root.addView(controls);

        TextView attribution = label(
                "© OpenStreetMap contributors · OSM data may be incomplete. Road signs and legal restrictions always prevail.",
                10, false);
        attribution.setGravity(Gravity.CENTER);
        attribution.setPadding(6, 5, 6, 7);
        root.addView(attribution);
        setContentView(root);
    }

    private TextView label(String text, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTextSize(size);
        if (bold) t.setTypeface(null, android.graphics.Typeface.BOLD);
        return t;
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(10);
        return b;
    }

    private boolean hasLocationPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void enableLocation() {
        if (!hasLocationPermission()) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_PERMISSION);
            return;
        }
        if (locationOverlay == null) {
            locationOverlay = new MyLocationNewOverlay(new GpsMyLocationProvider(this), map);
            locationOverlay.enableMyLocation();
            locationOverlay.enableFollowLocation();
            map.getOverlays().add(locationOverlay);
            locationOverlay.runOnFirstFix(() -> runOnUiThread(() -> {
                GeoPoint p = locationOverlay.getMyLocation();
                if (p != null) {
                    currentPoint = p;
                    map.getController().animateTo(p);
                    status.setText("GPS fix acquired. Choose a destination.");
                }
            }));
        } else {
            locationOverlay.enableMyLocation();
            locationOverlay.enableFollowLocation();
        }
        Toast.makeText(this, "GPS enabled. Wait for a reliable position fix.", Toast.LENGTH_SHORT).show();
    }

    private void searchDestination() {
        String query = destinationInput.getText().toString().trim();
        if (query.isEmpty()) {
            toast("Enter a destination first.");
            return;
        }
        status.setText("Searching OpenStreetMap address index…");
        io.execute(() -> {
            HttpURLConnection c = null;
            try {
                String url = "https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&q="
                        + URLEncoder.encode(query, "UTF-8");
                c = (HttpURLConnection) new URL(url).openConnection();
                c.setRequestProperty("User-Agent", "TruckNavigatorEurope/0.3.0 (Android app)");
                c.setConnectTimeout(15000);
                c.setReadTimeout(15000);
                JSONArray results = new JSONArray(read(c));
                if (results.length() == 0) throw new Exception("No matching destination found.");
                JSONObject hit = results.getJSONObject(0);
                double lat = hit.getDouble("lat");
                double lon = hit.getDouble("lon");
                String display = hit.optString("display_name", query);
                runOnUiThread(() -> {
                    destinationPoint = new GeoPoint(lat, lon);
                    if (destinationMarker != null) map.getOverlays().remove(destinationMarker);
                    destinationMarker = new Marker(map);
                    destinationMarker.setPosition(destinationPoint);
                    destinationMarker.setTitle("Destination");
                    destinationMarker.setSnippet(display);
                    map.getOverlays().add(destinationMarker);
                    map.getController().animateTo(destinationPoint);
                    map.getController().setZoom(14.0);
                    status.setText("Destination selected. Check the pin, then request truck routing.");
                });
            } catch (Exception e) {
                runOnUiThread(() -> status.setText("Address search failed: " + e.getMessage()));
            } finally {
                if (c != null) c.disconnect();
            }
        });
    }

    private void calculateTruckRoute(boolean automatic) {
        if (locationOverlay != null && locationOverlay.getMyLocation() != null)
            currentPoint = locationOverlay.getMyLocation();
        if (currentPoint == null) {
            toast("GPS position not available. Press GPS and wait for a fix.");
            return;
        }
        if (destinationPoint == null) {
            toast("Search for a destination first.");
            return;
        }
        if (routeRequestRunning) return;

        String base = prefs.getString("routing_url", DEMO_ROUTER).trim();
        if (base.isEmpty()) base = DEMO_ROUTER;
        final String router = base.replaceAll("/+$", "");
        final GeoPoint origin = currentPoint;
        final GeoPoint destination = destinationPoint;
        final double height = profileNumber("height", 4.0);
        final double width = profileNumber("width", 2.55);
        final double length = profileNumber("length", 16.5);
        final double weight = profileNumber("weight", 40.0);
        final double axleLoad = profileNumber("axle_load", 11.5);
        final int axleCount = (int) profileNumber("axle_count", 5);
        final boolean hazmat = prefs.getBoolean("hazmat", false);

        if (height <= 0 || width <= 0 || length <= 0 || weight <= 0 || axleLoad <= 0 || axleCount <= 0) {
            toast("Vehicle profile contains invalid values.");
            return;
        }
        routeRequestRunning = true;
        status.setText(automatic ? "Recalculating truck route…" : "Calculating truck route…");
        io.execute(() -> {
            HttpURLConnection c = null;
            try {
                JSONObject req = new JSONObject();
                JSONArray locations = new JSONArray();
                locations.put(new JSONObject().put("lat", origin.getLatitude()).put("lon", origin.getLongitude()));
                locations.put(new JSONObject().put("lat", destination.getLatitude()).put("lon", destination.getLongitude()));
                req.put("locations", locations);
                req.put("costing", "truck");
                req.put("units", "kilometers");
                JSONObject truck = new JSONObject();
                truck.put("height", height);
                truck.put("width", width);
                truck.put("length", length);
                truck.put("weight", weight);
                truck.put("axle_load", axleLoad);
                truck.put("axle_count", axleCount);
                truck.put("hazmat", hazmat);
                req.put("costing_options", new JSONObject().put("truck", truck));
                req.put("directions_options", new JSONObject().put("units", "kilometers")
                        .put("language", Locale.getDefault().getLanguage()));

                c = (HttpURLConnection) new URL(router + "/route").openConnection();
                c.setRequestMethod("POST");
                c.setDoOutput(true);
                c.setConnectTimeout(20000);
                c.setReadTimeout(40000);
                c.setRequestProperty("Content-Type", "application/json");
                c.setRequestProperty("Accept", "application/json");
                c.setRequestProperty("X-Client-Id", CLIENT_ID);
                try (OutputStream os = c.getOutputStream()) {
                    os.write(req.toString().getBytes(StandardCharsets.UTF_8));
                }
                int code = c.getResponseCode();
                String body = read(c);
                if (code < 200 || code >= 300)
                    throw new Exception("Router HTTP " + code + ". " + body);

                JSONObject trip = new JSONObject(body).getJSONObject("trip");
                JSONObject summary = trip.optJSONObject("summary");
                JSONArray legs = trip.getJSONArray("legs");
                JSONObject leg = legs.getJSONObject(0);
                ArrayList<GeoPoint> points = decodePolyline6(leg.getString("shape"));
                if (points.size() < 2) throw new Exception("Router returned no usable route geometry.");

                ArrayList<Integer> indexes = new ArrayList<>();
                ArrayList<String> texts = new ArrayList<>();
                JSONArray maneuvers = leg.optJSONArray("maneuvers");
                if (maneuvers != null) {
                    for (int i = 0; i < maneuvers.length(); i++) {
                        JSONObject m = maneuvers.getJSONObject(i);
                        indexes.add(m.optInt("begin_shape_index", 0));
                        texts.add(m.optString("instruction", "Continue following the route."));
                    }
                }
                final double km = summary == null ? -1 : summary.optDouble("length", -1);
                final double seconds = summary == null ? -1 : summary.optDouble("time", -1);
                final ArrayList<GeoPoint> finalPoints = points;
                final ArrayList<Integer> finalIndexes = indexes;
                final ArrayList<String> finalTexts = texts;
                runOnUiThread(() -> {
                    if (routeLine != null) map.getOverlays().remove(routeLine);
                    routeLine = new Polyline();
                    routeLine.setPoints(finalPoints);
                    routeLine.setColor(0xFF00A6FF);
                    routeLine.setWidth(10f);
                    map.getOverlays().add(routeLine);
                    activeRoutePoints.clear();
                    activeRoutePoints.addAll(finalPoints);
                    maneuverIndexes.clear();
                    maneuverIndexes.addAll(finalIndexes);
                    maneuverTexts.clear();
                    maneuverTexts.addAll(finalTexts);
                    lastAnnouncedManeuver = -1;
                    lastRerouteAt = System.currentTimeMillis();
                    map.invalidate();
                    String first = maneuverTexts.isEmpty() ? "Route calculated. Follow road signs." : maneuverTexts.get(0);
                    instruction.setText(first);
                    if (km >= 0 && seconds >= 0) {
                        tripInfo.setText(String.format(Locale.getDefault(),
                                "%.1f km  •  approx. %.0f min  •  %d manoeuvres",
                                km, seconds / 60.0, maneuverTexts.size()));
                    } else tripInfo.setText("Truck route received. Review route before departure.");
                    status.setText("Truck-costing route returned by " + router
                            + ". Map data completeness is not guaranteed.");
                    if (ttsReady) tts.speak(first, TextToSpeech.QUEUE_FLUSH, null, "route_start");
                    startBackgroundNavigation();
                    if (activeRoutePoints.size() > 1) {
                        map.getController().animateTo(activeRoutePoints.get(0));
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> status.setText("Truck route failed: " + e.getMessage()
                        + " · No car-route fallback was used."));
            } finally {
                routeRequestRunning = false;
                if (c != null) c.disconnect();
            }
        });
    }

    private void updateNavigationProgress() {
        if (locationOverlay == null || activeRoutePoints.size() < 2) return;
        GeoPoint fix = locationOverlay.getMyLocation();
        if (fix == null) return;
        currentPoint = fix;

        int nearest = 0;
        float nearestDistance = Float.MAX_VALUE;
        float[] result = new float[1];
        for (int i = 0; i < activeRoutePoints.size(); i++) {
            GeoPoint p = activeRoutePoints.get(i);
            Location.distanceBetween(fix.getLatitude(), fix.getLongitude(),
                    p.getLatitude(), p.getLongitude(), result);
            if (result[0] < nearestDistance) {
                nearestDistance = result[0];
                nearest = i;
            }
        }
        tripInfo.setText(String.format(Locale.getDefault(),
                "On route · %.0f m from route line", nearestDistance));

        int next = -1;
        for (int i = 0; i < maneuverIndexes.size(); i++) {
            if (maneuverIndexes.get(i) >= nearest) { next = i; break; }
        }
        if (next >= 0 && next != lastAnnouncedManeuver && nearestDistance < 100) {
            lastAnnouncedManeuver = next;
            String text = maneuverTexts.get(next);
            instruction.setText(text);
            if (ttsReady) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "maneuver_" + next);
        }

        // Conservative off-route alert only. Automatic rerouting is not silently triggered
        // because GPS multipath and imperfect map matching can create false positives.
        if (nearestDistance > 120) {
            status.setText("Off route or GPS drift detected. Stop safely and request a new truck route.");
        }
    }

    private void startBackgroundNavigation() {
        if (activeRoutePoints.size() < 2) {
            toast("Calculate a truck route before starting navigation.");
            return;
        }
        if (!hasLocationPermission()) {
            toast("Location permission is required for navigation.");
            enableLocation();
            return;
        }
        try {
            JSONArray pts = new JSONArray();
            for (GeoPoint p : activeRoutePoints) {
                JSONArray xy = new JSONArray();
                xy.put(p.getLatitude());
                xy.put(p.getLongitude());
                pts.put(xy);
            }
            JSONArray indexes = new JSONArray();
            for (Integer i : maneuverIndexes) indexes.put(i);
            JSONArray texts = new JSONArray();
            for (String s : maneuverTexts) texts.put(s);

            Intent intent = new Intent(this, TruckNavigationService.class);
            intent.setAction(TruckNavigationService.ACTION_START);
            intent.putExtra(TruckNavigationService.EXTRA_POINTS, pts.toString());
            intent.putExtra(TruckNavigationService.EXTRA_MANEUVER_INDEXES, indexes.toString());
            intent.putExtra(TruckNavigationService.EXTRA_MANEUVER_TEXTS, texts.toString());
            ContextCompat.startForegroundService(this, intent);
            status.setText("Background route monitoring started. Keep the notification visible.");
        } catch (Exception e) {
            status.setText("Could not start background navigation: " + e.getMessage());
        }
    }

    private void stopBackgroundNavigation() {
        Intent intent = new Intent(this, TruckNavigationService.class);
        intent.setAction(TruckNavigationService.ACTION_STOP);
        startService(intent);
        status.setText("Background navigation stopped.");
    }

    private ArrayList<GeoPoint> decodePolyline6(String encoded) {
        ArrayList<GeoPoint> out = new ArrayList<>();
        int index = 0, lat = 0, lon = 0;
        while (index < encoded.length()) {
            int b, shift = 0, result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20 && index < encoded.length());
            lat += ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            shift = 0; result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20 && index < encoded.length());
            lon += ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            out.add(new GeoPoint(lat / 1e6, lon / 1e6));
        }
        return out;
    }

    private double profileNumber(String key, double fallback) {
        try { return Double.parseDouble(prefs.getString(key, String.valueOf(fallback))); }
        catch (Exception ignored) { return fallback; }
    }

    private void showProfile() {
        LinearLayout form = new LinearLayout(this);
        form.setPadding(18, 4, 18, 4);
        form.setOrientation(LinearLayout.VERTICAL);
        EditText h = field(form, "Vehicle height (m)", "height", "4.0");
        EditText w = field(form, "Vehicle width (m)", "width", "2.55");
        EditText l = field(form, "Total combination length (m)", "length", "16.5");
        EditText g = field(form, "Gross vehicle weight (tonnes)", "weight", "40");
        EditText a = field(form, "Maximum axle load (tonnes)", "axle_load", "11.5");
        EditText n = field(form, "Number of axles", "axle_count", "5");
        android.widget.CheckBox haz = new android.widget.CheckBox(this);
        haz.setText("Carrying hazardous materials (generic HAZMAT flag)");
        haz.setTextColor(Color.WHITE);
        haz.setChecked(prefs.getBoolean("hazmat", false));
        form.addView(haz);

        new AlertDialog.Builder(this).setTitle("Vehicle profile · metric units").setView(form)
                .setMessage("Set actual vehicle + trailer values. Valhalla's standard truck costing supports dimensions, gross weight, axle load/count and a generic hazmat flag. It does not by itself certify ADR class/tunnel-code compliance.")
                .setPositiveButton("SAVE", (d, which) -> {
                    try {
                        double hv = Double.parseDouble(h.getText().toString());
                        double wv = Double.parseDouble(w.getText().toString());
                        double lv = Double.parseDouble(l.getText().toString());
                        double gv = Double.parseDouble(g.getText().toString());
                        double av = Double.parseDouble(a.getText().toString());
                        int nv = Integer.parseInt(n.getText().toString());
                        if (hv <= 0 || wv <= 0 || lv <= 0 || gv <= 0 || av <= 0 || nv <= 0)
                            throw new NumberFormatException();
                        prefs.edit().putString("height", h.getText().toString())
                                .putString("width", w.getText().toString())
                                .putString("length", l.getText().toString())
                                .putString("weight", g.getText().toString())
                                .putString("axle_load", a.getText().toString())
                                .putString("axle_count", n.getText().toString())
                                .putBoolean("hazmat", haz.isChecked()).apply();
                        toast("Vehicle profile saved.");
                    } catch (Exception ex) {
                        toast("Invalid vehicle profile. Please enter positive metric values.");
                    }
                }).setNegativeButton("CANCEL", null).show();
    }

    private EditText field(LinearLayout parent, String hint, String key, String def) {
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(0xFFBBBBBB);
        e.setHint(hint);
        e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER
                | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        e.setText(prefs.getString(key, def));
        parent.addView(e);
        return e;
    }

    private void configureServer() {
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setText(prefs.getString("routing_url", DEMO_ROUTER));
        e.setHint("https://your-own-valhalla-server");
        new AlertDialog.Builder(this).setTitle("Truck routing server")
                .setMessage("Default is the community Valhalla demo server for light testing only. For dependable personal use, enter your own Valhalla server URL built from current regional OSM data.")
                .setView(e)
                .setPositiveButton("SAVE", (d, w) -> {
                    String value = e.getText().toString().trim();
                    prefs.edit().putString("routing_url", value.isEmpty() ? DEMO_ROUTER : value).apply();
                    status.setText("Routing endpoint saved.");
                }).setNeutralButton("USE COMMUNITY DEMO", (d, w) -> {
                    prefs.edit().putString("routing_url", DEMO_ROUTER).apply();
                    status.setText("Community demo selected. Fair-use limits apply.");
                }).setNegativeButton("CANCEL", null).show();
    }

    private String read(HttpURLConnection c) throws Exception {
        java.io.InputStream in = c.getResponseCode() >= 400 ? c.getErrorStream() : c.getInputStream();
        if (in == null) return "";
        StringBuilder s = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) s.append(line);
        }
        return s.toString();
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    @Override public void onRequestPermissionsResult(int code, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(code, permissions, results);
        if (code == LOCATION_PERMISSION && hasLocationPermission()) enableLocation();
    }

    @Override protected void onResume() {
        super.onResume();
        if (map != null) map.onResume();
        mainHandler.post(progressTask);
    }

    @Override protected void onPause() {
        mainHandler.removeCallbacks(progressTask);
        if (map != null) map.onPause();
        super.onPause();
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        io.shutdown();
        super.onDestroy();
    }
}
